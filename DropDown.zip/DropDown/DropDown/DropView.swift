//
//  DropView.swift
//  DropDown
//
//  Created by admin on 10/11/18.
//  Copyright © 2018 cuongnv. All rights reserved.
//

import UIKit

class DropView: UIView {
    
    @IBInspectable var maxHeightDropDown: CGFloat = 150
    
    private var heightArC = NSLayoutConstraint()
    
    private var isDropDown = false
    private var viewClear: UIView = UIView()
    private var dropDown = DropDown(frame: .zero)
    private var contenSizeDropDown: (status: Bool,size: CGSize) = (true, CGSize.zero) {
        didSet {
            setAnimation(contenSizeDropDown.status, contentSize: contenSizeDropDown.size)
        }
    }
    
    private weak var currentVC: UIViewController? {
        guard let windowCurrent = UIApplication.shared.delegate?.window else { return nil }
        return windowCurrent?.rootViewController
    }
    
    override func draw(_ rect: CGRect) {

        currentVC?.view.addSubview(dropDown)
        dropDown.translatesAutoresizingMaskIntoConstraints = false
        dropDown.topAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
        dropDown.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        dropDown.widthAnchor.constraint(equalTo: self.widthAnchor).isActive = true
        heightArC = dropDown.heightAnchor.constraint(equalToConstant: 0)
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        viewClear = UIView(frame: UIScreen.main.bounds)
        viewClear.backgroundColor = UIColor.clear
        viewClear.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(tappClearView)))
        currentVC?.view.addSubview(viewClear)
        
        isDropDown ? hidenDrop() : showDrop()
    }
    
    private func showDrop() {
        guard !isDropDown else { return }
        isDropDown = true
        
        currentVC?.view.bringSubviewToFront(dropDown)
        
        //return content tableView if contentDropView > maxHeight
        let heightTable = self.dropDown.tableView.contentSize.height
        let height = heightTable > maxHeightDropDown ? maxHeightDropDown : heightTable
        
        contenSizeDropDown = (isDropDown, CGSize(width: 0, height: height))
    }
    
    private func hidenDrop() {
        isDropDown = false
        
        viewClear.removeFromSuperview()
        contenSizeDropDown = (isDropDown, CGSize.zero)
    }
    
    private func setAnimation(_ isShow: Bool, contentSize: CGSize) {
        
        NSLayoutConstraint.deactivate([self.heightArC])
        self.heightArC.constant = contentSize.height
        NSLayoutConstraint.activate([self.heightArC])
        
        UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: .curveEaseInOut, animations: {
            if isShow {
                self.dropDown.layoutIfNeeded()
                self.dropDown.center.y += self.dropDown.frame.height / 2
            }else {
                self.dropDown.center.y -= self.dropDown.frame.height / 2
                self.dropDown.layoutIfNeeded()
            }
        }, completion: nil)
    }
    
    @objc private func tappClearView() {
        hidenDrop()
    }
}
